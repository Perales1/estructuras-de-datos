var searchData=
[
  ['latmax_0',['latmax',['../struct_datos_geograficos.html#a2e22c7426fb3c789eea71824f2b1d954',1,'DatosGeograficos']]],
  ['latmin_1',['latmin',['../struct_datos_geograficos.html#af22cdca1ae3fd17e763b2b14a849df71',1,'DatosGeograficos']]],
  ['lonmax_2',['lonmax',['../struct_datos_geograficos.html#a738998f0fbf4918d1ec901b0b27a5ebe',1,'DatosGeograficos']]],
  ['lonmin_3',['lonmin',['../struct_datos_geograficos.html#a42c54117ec0560370991f40b48a2c419',1,'DatosGeograficos']]]
];
