var searchData=
[
  ['numcolumnas_0',['numColumnas',['../class_img.html#ae36d7ad9a48c1c148ad12bb7e2224015',1,'Img']]],
  ['numfilas_1',['numFilas',['../class_img.html#ad0988469177bb616a8175a4cfacfbfaa',1,'Img']]],
  ['nummax10_2',['numMax10',['../class_thash_usuario.html#af450de56c98a104955eb59ed88d37814',1,'ThashUsuario']]]
];
