var searchData=
[
  ['datosgeograficos_0',['DatosGeograficos',['../struct_datos_geograficos.html',1,'']]]
];
