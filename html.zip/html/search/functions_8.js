var searchData=
[
  ['img_0',['Img',['../class_img.html#a987bd588dbd05bb39272e00846cdb9c0',1,'Img::Img(int filas, int columnas)'],['../class_img.html#ab8b0f8fca3826501d9d1b14448bcbeb2',1,'Img::Img(int filas, int columnas, RGBColor &amp;color)'],['../class_img.html#af062943b3f49b6191d884747f9257ba2',1,'Img::Img(const string &amp;fileName)']]],
  ['iniciartrayecto_1',['iniciarTrayecto',['../class_usuario.html#a83011b95d8a9bfa491e8db475df4fb3c',1,'Usuario']]],
  ['inserta_2',['inserta',['../class_casilla.html#acaa8cc6bcabbda51772c0d7cf4df0b4a',1,'Casilla']]],
  ['insertacoche_3',['insertacoche',['../class_reanelcar.html#aae7584d842d4d5903030089ef1723707',1,'Reanelcar']]],
  ['insertar_4',['insertar',['../class_thash_usuario.html#a16de1a9c286171d37834abe216a23eb7',1,'ThashUsuario::insertar()'],['../class_malla_regular.html#acebc8596a72412537a6ac40cef8f477f',1,'MallaRegular::insertar()']]],
  ['insertausuario_5',['insertausuario',['../class_reanelcar.html#a79d624b5465d6ed2770c52084f9df10f',1,'Reanelcar']]]
];
