var searchData=
[
  ['reanelcar_0',['Reanelcar',['../class_reanelcar.html#a97ac530eeb33a1209b97d8fd578477b1',1,'Reanelcar::Reanelcar()'],['../class_reanelcar.html#ad5c57c71b7992d4aad6b776e696765bb',1,'Reanelcar::Reanelcar(std::map&lt; std::string, Coche &gt; &amp;coches)'],['../class_reanelcar.html#ac8b08068460b035427e243bed0ffc54a',1,'Reanelcar::Reanelcar(std::map&lt; std::string, Coche &gt; &amp;coches, std::list&lt; Usuario &gt; &amp;usuarios)'],['../class_reanelcar.html#a86f6a2fc1762c3c1c0bde944e2da2140',1,'Reanelcar::Reanelcar(std::map&lt; std::string, Coche &gt; &amp;coches, std::list&lt; Usuario &gt; &amp;usuarios, std::vector&lt; PuntoRecarga &gt; &amp;puntoRecarga)'],['../class_reanelcar.html#acf58f723007a48d94458454613461841',1,'Reanelcar::Reanelcar(std::map&lt; std::string, Coche &gt; &amp;coches, std::list&lt; Usuario &gt; &amp;usuarios, std::vector&lt; PuntoRecarga &gt; &amp;puntoRecarga, ThashUsuario &amp;usersNif)']]],
  ['redispersar_1',['redispersar',['../class_thash_usuario.html#a5f1b2d707f146b81361b17c9a0f42c46',1,'ThashUsuario']]],
  ['resetmalla_2',['resetMalla',['../class_malla_regular.html#a689f4856dc55aaa18f1a96f3f8a7d5b2',1,'MallaRegular']]],
  ['rgbcolor_3',['RGBColor',['../class_r_g_b_color.html#a9383ce7b63b0a6ada5d4e54e16adf733',1,'RGBColor::RGBColor()'],['../class_r_g_b_color.html#a73b3f87c0dc095bc72ea01d5ab8f4667',1,'RGBColor::RGBColor(unsigned char r, unsigned char g, unsigned char b)']]],
  ['rojo_4',['rojo',['../class_r_g_b_color.html#a3b761e106a764b1bda23346e19a0bbc3',1,'RGBColor']]]
];
