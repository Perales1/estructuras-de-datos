var searchData=
[
  ['vdinamico_0',['VDinamico',['../class_v_dinamico.html#af905a96dbf84b7a2e660b73b49e51e8d',1,'VDinamico::VDinamico()'],['../class_v_dinamico.html#ae3671cfadf2221d9457fa20624c2be97',1,'VDinamico::VDinamico(unsigned int _tamlogico)'],['../class_v_dinamico.html#a6082f1c5065149847b6040831c004fed',1,'VDinamico::VDinamico(const VDinamico&lt; T &gt; &amp;other)'],['../class_v_dinamico.html#a7ab5f780a3e6b616fad1557071945944',1,'VDinamico::VDinamico(const VDinamico&lt; T &gt; &amp;other, unsigned int posicioninicial, unsigned int numelementos)']]]
];
