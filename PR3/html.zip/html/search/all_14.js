var searchData=
[
  ['y_0',['y',['../struct_coordenadas.html#ad682030e6344d21bfeaa6c1f95c2539f',1,'Coordenadas']]]
];
