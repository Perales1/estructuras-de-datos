var searchData=
[
  ['cabeza_0',['cabeza',['../class_lista_d_enlazada.html#aa34608f477c06907bc0c6be49adf4acd',1,'ListaDEnlazada']]],
  ['cola_1',['cola',['../class_lista_d_enlazada.html#abe0d9cd44c04732bcf45e8ded239cd2e',1,'ListaDEnlazada']]]
];
