var searchData=
[
  ['puntorecarga_0',['PuntoRecarga',['../class_punto_recarga.html#a619e7c06aae87779524bc39b18f0d461',1,'PuntoRecarga::PuntoRecarga()=default'],['../class_punto_recarga.html#a002417b2d7dc8e1945c87c3d3b8c9b93',1,'PuntoRecarga::PuntoRecarga(int id_, const Coordenadas &amp;posicion_, unsigned int max_)'],['../class_punto_recarga.html#afdbe84e71183fdd8fa122219a7be95ad',1,'PuntoRecarga::PuntoRecarga(int id_)'],['../class_punto_recarga.html#a5f6a3027ccbf3146a88152b9af00a325',1,'PuntoRecarga::PuntoRecarga(int i, Coordenadas coordenadas)']]]
];
