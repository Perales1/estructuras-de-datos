var searchData=
[
  ['usuario_0',['Usuario',['../class_usuario.html',1,'Usuario'],['../class_usuario.html#af7d254a5dd3741a36fb76be1ee1e3207',1,'Usuario::Usuario()=default'],['../class_usuario.html#ab202f2e90d35ec473551291171db60d2',1,'Usuario::Usuario(std::string &amp;nif_, std::string &amp;clave_, std::string &amp;nombre_, std::string &amp;direccion)']]],
  ['usuario_2ecpp_1',['Usuario.cpp',['../_usuario_8cpp.html',1,'']]],
  ['usuario_2eh_2',['Usuario.h',['../_usuario_8h.html',1,'']]]
];
