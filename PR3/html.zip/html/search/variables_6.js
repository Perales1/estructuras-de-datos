var searchData=
[
  ['sig_0',['sig',['../class_nodo.html#a0879a04991c2565ba1827d55a11877c3',1,'Nodo']]]
];
