var searchData=
[
  ['x_0',['x',['../struct_coordenadas.html#a4203b7c576eb391ee70b0f3d818c3078',1,'Coordenadas']]]
];
