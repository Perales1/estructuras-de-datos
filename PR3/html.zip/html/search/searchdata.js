var indexSectionsWithContent =
{
  0: "abcdfghilmnopqrstuvxy~",
  1: "acilnpruv",
  2: "acilmpruv",
  3: "abcdfghilmnopqrstuv~",
  4: "abcdinstxy",
  5: "lo",
  6: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "related",
  6: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Friends",
  6: "Macros"
};

