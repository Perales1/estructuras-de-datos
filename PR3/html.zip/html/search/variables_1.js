var searchData=
[
  ['bal_0',['bal',['../class_nodo2.html#a9ede99b3b797dcf1d939f29f247a29e3',1,'Nodo2']]]
];
