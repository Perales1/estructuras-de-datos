var searchData=
[
  ['fecha_0',['Fecha',['../class_fecha.html#a5fbc6564d9c48e73cf8d27568a2a7fc5',1,'Fecha::Fecha()'],['../class_fecha.html#a2548cec49fb9b07debabd9ee0565514f',1,'Fecha::Fecha(unsigned aDia, unsigned aMes, unsigned aAnio, unsigned aHora=0, unsigned aMin=0)'],['../class_fecha.html#a7201e00ac3fa1e07dfa124f3bd999dec',1,'Fecha::Fecha(const Fecha &amp;f)']]],
  ['finalizartrayecto_1',['finalizarTrayecto',['../class_trayecto.html#a463d36b7723320de9dbb0177f9a3da94',1,'Trayecto']]]
];
