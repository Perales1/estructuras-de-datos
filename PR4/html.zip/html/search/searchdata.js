var indexSectionsWithContent =
{
  0: "abcdefgimoprstuv~",
  1: "cefprtu",
  2: "cfmprtu",
  3: "abcdfgimoprstuv~",
  4: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "related"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Friends"
};

