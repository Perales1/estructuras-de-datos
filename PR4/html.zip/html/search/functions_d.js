var searchData=
[
  ['usuario_0',['Usuario',['../class_usuario.html#a02d4978ef21e4b09da5c255c879f12eb',1,'Usuario::Usuario(std::string &amp;nif_, std::string &amp;clave_, std::string &amp;nombre_, std::string &amp;direccion, Reanelcar *link_)'],['../class_usuario.html#af7d254a5dd3741a36fb76be1ee1e3207',1,'Usuario::Usuario()=default'],['../class_usuario.html#ab202f2e90d35ec473551291171db60d2',1,'Usuario::Usuario(std::string &amp;nif_, std::string &amp;clave_, std::string &amp;nombre_, std::string &amp;direccion)']]],
  ['utm_1',['UTM',['../class_u_t_m.html#a11617331128d102e28a771bf59469d0b',1,'UTM::UTM()'],['../class_u_t_m.html#a9a6b34ee4aa28fca79dc68a4d3fc37d9',1,'UTM::UTM(float lat_, float lon_)']]]
];
