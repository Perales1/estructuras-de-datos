var searchData=
[
  ['nodo_0',['Nodo',['../class_nodo.html#a0a55215320d3e7f8fbfb80e2dea706b4',1,'Nodo']]]
];
