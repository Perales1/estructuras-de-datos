var indexSectionsWithContent =
{
  0: "abcdfghilmnoqrstuv~",
  1: "cilnruv",
  2: "cilmruv",
  3: "abcdfghilmnoqstuv~",
  4: "acdnstu",
  5: "lo"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "related"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Friends"
};

