var searchData=
[
  ['usuario_0',['Usuario',['../class_usuario.html#a52cc6f99c2eb915b7eb857950f6b9e60',1,'Usuario']]]
];
